# CP2K Source Code

## Code Structure

For information on CP2K's code structure, please refer to the [code structure documentation](https://www.cp2k.org/dev:codestructure).
